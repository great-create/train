
extern void Init_MAX7219(void);

extern void printC_MAX7219(char ascii);
