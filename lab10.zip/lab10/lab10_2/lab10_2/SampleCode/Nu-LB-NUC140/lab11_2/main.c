//
// I2C_IMU
//
// EVB : Nu-LB-NUC140
// MCU : NUC140VE3CN (LQFP100)
// IMU : MPU6050 (3-axis accelerometer & 3-axis gyroscope)
// 
// MPU6050 Connections
// SCL : to I2C0-SCL/PA9
// SDA : to I2C0-SDA/PA8

#include <stdio.h>
#include <math.h>
#include <string.h>
#include "NUC100Series.h"
#include "MCU_init.h"
#include "SYS_init.h"
#include "LCD.h"
#include "MPU6050.h"
#include "NVT_I2C.h"
#include "Seven_Segment.h"
int LIMIT=2000;
unsigned char ball[]={
 	0xE0,0xF0,0xFC,0xFC,0xFE,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFE,0xFC,0xFC,0xF8,0xE0
		,0x07,0x0F,0x3F,0x7F,0x7F,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x7F,0x7F,0x3F,0x1F,0x07


};
char Text[16];
volatile uint8_t KEY_Flag;
volatile uint32_t index_5ms, cnt_5ms, cnt_1s, cnt_100ms,index_key_scan;
volatile uint32_t digit[4];
volatile uint32_t count_Line, count_Char;
int8_t x=0,y=0; // initial position
int8_t keyin=0;
int8_t movX=3, dirX=0; // pixel per step! 
int8_t movY=3, dirY=0;// pixel per step! 
int8_t mov_state=0;// 1 2 3 4 up left right down 


void TMR1_IRQHandler(void)
{	
	cnt_5ms++;
	index_5ms = cnt_5ms % 4;
	CloseSevenSegment();
	if (index_5ms == 0) {			
//	ShowSevenSegment(0,digit[0]);				
	}	
	if (index_5ms == 1)  {
//	ShowSevenSegment(1,digit[1]);		
	}	
	if (index_5ms == 2)  {
	//ShowSevenSegment(2,digit[2]);		
	}
	if (index_5ms == 3)  {
	//ShowSevenSegment(3,digit[3]);
	}		
	if (cnt_5ms % 20 == 0) 
	{
		cnt_100ms++;
		index_key_scan = cnt_100ms++ % 3;
		if (index_key_scan == 0)
		{
			PA0=1; PA1=1; PA2=1; PA3=1; PA4=1; PA5=0;
		}
		if (index_key_scan == 1)
		{
			PA0=1; PA1=1; PA2=1; PA3=1; PA4=0; PA5=1;
		}
		if (index_key_scan == 2)
		{
			PA0=1; PA1=1; PA2=1; PA3=0; PA4=1; PA5=1;
		}
		NVIC_EnableIRQ(GPAB_IRQn);
	}
	
	if (cnt_5ms % 200 == 0) cnt_1s++;	

  TIMER_ClearIntFlag(TIMER1); // Clear Timer1 time-out interrupt flag
}

void GPAB_IRQHandler(void)
{
		NVIC_DisableIRQ(GPAB_IRQn);
	
if (PA->ISRC & BIT0) {        // check if PA0 interrupt occurred
		PA0=1;
	  PA->ISRC |= BIT0;         // clear PA0 interrupt status
	
if (PA3==0) { KEY_Flag =3; PA3=1;}
if (PA4==0) { KEY_Flag =6; PA4=1;}
if (PA5==0) { KEY_Flag =9; PA5=1;}
return;			
} 
if (PA->ISRC & BIT1) { // check if PA1 interrupt occurred
		PA1=1;
	  PA->ISRC |= BIT1;         // clear PA1 interrupt status  
if (PA3==0) { KEY_Flag =2; PA3=1;}
if (PA4==0) { KEY_Flag =5; PA4=1;}
if (PA5==0) { KEY_Flag =8; PA5=1;} 
return;				
} 
if (PA->ISRC & BIT2) { // check if PB14 interrupt occurred
		PA2=1;
	  PA->ISRC |= BIT2;         // clear PA interrupt status  
if (PA3==0) { KEY_Flag =1; PA3=1;}
if (PA4==0) { KEY_Flag =4; PA4=1;}
if (PA5==0) { KEY_Flag =7; PA5=1;}
return;				
}                     // else it is unexpected interrupts
PA->ISRC = PA->ISRC;	      // clear all GPB pins
}


void Init_Timer1(void)
{
  TIMER_Open(TIMER1, TIMER_PERIODIC_MODE, 200);
  TIMER_EnableInt(TIMER1);
  NVIC_EnableIRQ(TMR1_IRQn);
  TIMER_Start(TIMER1);
}

void Init_KEY(void)
{
		GPIO_SetMode(PA, (BIT0 | BIT1 | BIT2 |BIT3 | BIT4 | BIT5), GPIO_MODE_QUASI);
		GPIO_EnableInt(PA, 0, GPIO_INT_LOW);
		GPIO_EnableInt(PA, 1, GPIO_INT_LOW);
		GPIO_EnableInt(PA, 2, GPIO_INT_LOW);		
		NVIC_EnableIRQ(GPAB_IRQn);   
	  NVIC_SetPriority(GPAB_IRQn,3);
		GPIO_SET_DEBOUNCE_TIME(GPIO_DBCLKSRC_LIRC, GPIO_DBCLKSEL_256);
		GPIO_ENABLE_DEBOUNCE(PA, (BIT0 | BIT1 | BIT2));			
}
void setDirectionUp() {
    dirX += 0;
    dirY += -1;
	mov_state=1;
}

void setDirectionLeft() {
    dirX += -1;
    dirY += 0;
	mov_state=2;
}

void setDirectionRight() {
    dirX += 1;
    dirY += 0;
	mov_state=3;
}

void setDirectionDown() {
    dirX += 0;
    dirY += 1;
	mov_state=4;
}
int32_t main()
{
  int16_t ax[1], ay[1], az[1];	
  int16_t gx[1], gy[1], gz[1];
	
  SYS_Init();
  init_LCD();
  clear_LCD();
 
	Init_Timer1();
	Init_KEY();
  //OpenSevenSegment();
	 //print_Line(0,"IMU: MPU6050");
  NVT_I2C_Init(I2C1_CLOCK_FREQUENCY);
//print_Line(1,"788");
  MPU6050_address(MPU6050_DEFAULT_ADDRESS);
//	print_Line(2,"34555");
  MPU6050_initialize();
//print_Line(3,"345");
  while(1) {		
    MPU6050_getAcceleration(ax, ay, az);
    MPU6050_getRotation(gx, gy, gz);
		//draw_Bmp16x16(32,32,1,0,ball);
    sprintf(Text, "ax%6d gX%6d", ax[0], gx[0]);
   // print_Line(1,Text);
    sprintf(Text, "ay%6d gY%6d", ay[0], gy[0]);
   // print_Line(2,Text);
    sprintf(Text, "az%6d gZ%6d", az[0], gz[0]);
    //print_Line(3,Text);		
		CLK_SysTickDelay(100000);
		draw_Bmp16x16(x,y,0,0,ball);
		
		//setDirectionRight();
		dirX=0;
		dirY=0;
		if(ax[0]<-LIMIT){
				if(x<LCD_Xmax - 16)
				setDirectionRight();
				else
					x=LCD_Xmax-16;
				}
		if(ax[0]>LIMIT){
				if(x>0)
				setDirectionLeft();
				else 
					x=0;
		}
	  if(ay[0]<-LIMIT){
				if(y>0)
			setDirectionUp();
				else
					y=0;
		}
		if(ay[0]>LIMIT){
				if(y<LCD_Ymax - 16)
				setDirectionDown();
				else
					y=LCD_Ymax-16;
		}
		if(ax[0]<LIMIT&&ax[0]>-LIMIT&&ay[0]<LIMIT&&ay[0]>-LIMIT){
			dirX=dirY=0;
			draw_Bmp16x16(x,y,1,0,ball);
		}
		
		
		
		x=x + dirX * movX; // increment/decrement X
		y=y + dirY * movY; // increment/decrement Y
		
		if(y>LCD_Ymax-16){
				y=LCD_Ymax-16;
		}
		if(y<0){
			y=0;
		}
		if(x>LCD_Xmax-16){
			x=LCD_Xmax-16;
		}
		if(x<0){
			x=0;
		}
		
		
		draw_Bmp16x16(x,y,1,0,ball);
    }

}
