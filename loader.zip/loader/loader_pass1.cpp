#include <bits/stdc++.h>
#include "try2.h"

string PROGADDR, CSADDR, CSLTH;
estab ESTAB;
using namespace std;
int main()
{
    PROGADDR = get_program_address_from_os();
    CSADDR = PROGADDR;
    fstream objcode;
    objcode.open("objcode.txt", ios::in);
    if (objcode.is_open())
    {
        string op;
        while (getline(objcode, op))
        {
            read(op);
            bool found = search_estab(csect_name(op));
            if (found)
            {
                cout << "Error duplicate control section name ! \n";
            }
            else
            {
                enter_control_section_name_into_ESTAB_with_value_CSADDR(op);
            }
            while (record_type(op) != 'E')
            {
                getline(objcode, op);

                if (record_type(op) == 'D')
                {
                    process(op);
                }
            }
            CSADDR = int_to_hex(hex_to_int(CSADDR) + hex_to_int(CSLTH));
        }
        objcode.close();
    }

    display_ESTAB();

    return 0;
}

/* g++ loader_pass1.cpp -o p1.exe
	cmd p1.exe */
